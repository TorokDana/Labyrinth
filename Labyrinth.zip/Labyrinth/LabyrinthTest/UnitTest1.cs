using Microsoft.VisualStudio.TestTools.UnitTesting;
using Labirintus.Model;
using Labirintus.Persistence;
using System;



namespace LabyrinthTest
{
    [TestClass]
    public class LabyrinthGameModelTest
    {

        public LabyrinthFileDataAccess _dataAccess; // adatel�r�s
        private LabyrinthGameModel _model; // j�t�kmodell

       

       
       


        [TestMethod]
        public void NewGameSmall()
        {
             _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);
           
            _model.GameDifficulty = GameDifficulty.Easy;
            _model.NewGame();

            Assert.AreEqual(_model.GameDifficulty,GameDifficulty.Easy);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(9, 0));
            Assert.AreEqual(_model.IsGameOver, false);
            Assert.AreEqual(_model.GameTime,0);
            

        }


        [TestMethod]
        
        public void NewGameMedium()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Medium;
            _model.NewGame();

            Assert.AreEqual(_model.GameDifficulty, GameDifficulty.Medium);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(14, 0));
            Assert.AreEqual(_model.IsGameOver, false);
            Assert.AreEqual(_model.GameTime, 0);

        }


        [TestMethod]

        public void NewGameHard()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Hard;
            _model.NewGame();

            Assert.AreEqual(_model.GameDifficulty, GameDifficulty.Hard);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(19, 0));
            Assert.AreEqual(_model.IsGameOver, false);
            Assert.AreEqual(_model.GameTime, 0);

        }


        [TestMethod]

        public void StepRight()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Easy;
            _model.NewGame();

            Tuple<Int32, Int32> cor = Tuple.Create(_model.CurCoord().Item1,_model.CurCoord().Item2);
            _model.Step(3);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1, cor.Item2 + 1));

             cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(3);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1, cor.Item2 + 1));

        }

        [TestMethod]

        public void StepLeft()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Easy;
            _model.NewGame();
            _model.Step(3);
            _model.Step(3);
            Tuple<Int32, Int32> cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(4);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1, cor.Item2-1 ));

            cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(4);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1, cor.Item2-1));

        }


        [TestMethod]
        public void StepUp()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Medium;
            _model.NewGame();
           
            Tuple<Int32, Int32> cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(1);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1-1, cor.Item2 ));

            cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(1);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1-1, cor.Item2));

        }


        [TestMethod]
        public void StepDown()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Medium;
            _model.NewGame();
            _model.Step(1);
            _model.Step(1);

            Tuple<Int32, Int32> cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(2);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1 + 1, cor.Item2 ));

            cor = Tuple.Create(_model.CurCoord().Item1, _model.CurCoord().Item2);
            _model.Step(2);
            Assert.AreEqual(_model.CurCoord(), Tuple.Create(cor.Item1 + 1, cor.Item2 ));

        }

        [TestMethod]
        public void AdvanceTime()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Hard;
            _model.NewGame();

            Int32 time = _model.GameTime;
            while (time <20)
            {
                _model.AdvanceTime();

                time++;

                Assert.AreEqual(time, _model.GameTime); // az id� cs�kkent
                Assert.AreEqual(Tuple.Create(19, 0), _model.CurCoord()); // de a l�p�ssz�m nem v�ltozott
            }

        }

        [TestMethod]
        public void GameOver()
        {
            _dataAccess = new LabyrinthFileDataAccess();
            _model = new LabyrinthGameModel(_dataAccess);

            _model.GameDifficulty = GameDifficulty.Easy;
            _model.NewGame();

            Random rnd = new Random();

            for (int i = 0; i < 100; i++)
            {
                int step = rnd.Next(1, 5);
                _model.Step(step);
                Assert.AreEqual(_model.IsGameOver, _model.CurCoord() == Tuple.Create(0, 9));

            }                
             
          

        }

    }
}
