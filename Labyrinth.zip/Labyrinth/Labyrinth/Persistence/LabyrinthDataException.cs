﻿using System;


namespace Labirintus.Persistence
{
    public class LabyrinthDataException : Exception
    {
        /// <summary>
        /// Sudoku adatelérés kivétel példányosítása.
        /// </summary>
        public LabyrinthDataException() { }
    }
}
